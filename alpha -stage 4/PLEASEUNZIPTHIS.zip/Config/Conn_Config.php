<?php

class Connection{
    public static $Host = "localhost:3306";
    public static $DB_Id = "root";
    public static $DB_Pw = "";
    public static $Schema = "evalley";
}

