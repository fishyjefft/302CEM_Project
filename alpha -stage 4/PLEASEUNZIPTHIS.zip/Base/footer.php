
	
	<!-- Footer -->
	<head>
	<link rel="stylesheet" href="footer.css">
	</head>
    <footer class=" footer py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Your Website 2018</p>
      </div>
      <!-- /.container -->
    </footer>
	<!-- Bootstrap core JavaScript -->
	<!-- Bootstrap core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.js"></script>
  </body>

</html>
